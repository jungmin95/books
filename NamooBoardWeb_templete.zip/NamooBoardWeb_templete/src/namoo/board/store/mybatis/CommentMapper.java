package namoo.board.store.mybatis;

import java.util.List;

import namoo.board.domain.Comment;

public interface CommentMapper {
	
	void insert(Comment comment);
	List<Comment> selectAll(String articleId);
	void delete(String commentId);

}
