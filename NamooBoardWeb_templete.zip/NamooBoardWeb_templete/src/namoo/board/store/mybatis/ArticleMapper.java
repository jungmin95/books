package namoo.board.store.mybatis;

import java.util.List;

import namoo.board.domain.Article;

public interface ArticleMapper {
	
	void insert(Article article);
	Article select(String articleId);
	List<Article> selectAll(String boardId);
	void update(Article article);
	void delete(String articleId);

}
