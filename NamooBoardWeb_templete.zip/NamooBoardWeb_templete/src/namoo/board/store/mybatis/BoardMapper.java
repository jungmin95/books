package namoo.board.store.mybatis;

import java.util.List;

import namoo.board.domain.Board;

public interface BoardMapper {
	
	void insert(Board board);
	Board select(String boardId);
	void update(Board board);
	List<Board> selectAll();
	void delete(String boardId);

}
